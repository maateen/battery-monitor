# battery-monitor
It's a Python3 script which will notify user about charging, discharging and not charging state of the battery on Linux. It's using PyGtk3 for notification.
